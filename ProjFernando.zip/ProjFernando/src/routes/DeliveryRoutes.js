const express = require("express");
const deliveryController = require("../controllers/EnterpriseController");

const Router = express.Router();

// Create
Router.post("/delivery/create", deliveryController.createDelivery);

// Read
Router.get("/deliveries", deliveryController.findAllDeliveries);

// Update
Router.patch("/delivery/:id/update", deliveryController.updateDeliveryById);

// Delete
Router.delete("/delivery/:id/delete", deliveryController.deleteDeliveryById);

module.exports = Router
