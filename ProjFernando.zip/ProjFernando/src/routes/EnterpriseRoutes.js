const express = require("express")
const enterpriseController = require("../controllers/EnterpriseController")

const Router = express.Router()

//Create
Router.post('/enterprise/register', enterpriseController.register)
//Read
Router.get('/enterprise/:id', enterpriseController.findById)
//Update
Router.patch('/enterprise/:id', enterpriseController.updateById)
//Delete
Router.delete('/enterprise/:id', enterpriseController.deleteById)

module.exports = Router