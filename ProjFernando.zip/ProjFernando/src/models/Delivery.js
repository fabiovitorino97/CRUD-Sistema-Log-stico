const mongoose = require("mongoose");

const deliverySchema = new mongoose.Schema({
  product: {
    type: String,
    required: [true, "O campo 'product' é obrigatório"],
  },
  remainingTime: {
    type: Number,
    default: 1800, // Valor padrão de 30 minutos em segundos
  },
  status: {
    type: String,
    enum: ["Em andamento", "Concluído", "Cancelado"],
    default: "Em andamento",
  },
  client: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Client",
  },
});

module.exports = mongoose.model("Delivery", deliverySchema);
