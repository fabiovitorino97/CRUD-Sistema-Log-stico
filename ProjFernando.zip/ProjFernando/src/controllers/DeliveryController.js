const Delivery = require("../models/Delivery");
const { StatusCodes } = require("http-status-codes");

const createDelivery = async (req, res) => {
  const delivery = await Delivery.create(req.body);

  res.status(StatusCodes.CREATED).json({
    delivery: {
      _id: delivery.id,
      product: delivery.product,
      remainingTime: delivery.remainingTime,
      status: delivery.status,
      client: delivery.client,
    },
  });
};

const findAllDeliveries = async (req, res) => {
  const deliveries = await Delivery.find();

  res.status(StatusCodes.OK).json({ deliveries });
};

const updateDeliveryById = async (req, res) => {
  const updatedDelivery = await Delivery.findByIdAndUpdate(
    req.params.id,
    req.body,
    {
      new: true,
    }
  );

  res.status(StatusCodes.OK).json({ updatedDelivery });
};

const deleteDeliveryById = async (req, res) => {
  await Delivery.findByIdAndDelete(req.params.id);

  res.status(StatusCodes.OK).json({ message: "Entrega deletada com sucesso" });
};

const deliveryController = {
  createDelivery,
  findAllDeliveries,
  updateDeliveryById,
  deleteDeliveryById,
};

module.exports = deliveryController;
