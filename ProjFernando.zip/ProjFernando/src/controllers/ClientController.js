const Client = require("../models/Client");
const { StatusCodes } = require("http-status-codes");

const register = async (req, res) => {
  const client = await Client.create(req.body);

  res.status(StatusCodes.CREATED).json({
    client: {
      _id: client.id,
      name: client.nome,
      role: "cliente",
    },
  });
};

const findById = async (req, res) => {
  const client = await Client.findById(req.params.id)

  return res.status(StatusCodes.OK).json({client})
};

const updateById = async (req,res) => {
    const updateClient = await Client.findByIdAndUpdate(req.params.id , req.body, {
        new: true,
    })

    return res.status(StatusCodes.OK).json({updateClient})
}

const deleteById = async (req,res) => {
    const admin = await Client.findByIdAndDelete(req.params.id)

    return res.status(StatusCodes.OK).json({ msg: 'usuário deletado com sucesso'})

}

const clientController = { register, findById, updateById, deleteById };

module.exports = clientController