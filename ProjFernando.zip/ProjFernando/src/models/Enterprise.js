const mongoose = require('mongoose')
const bcrypt = require('bcryptjs')

const enterpriseSchema = new mongoose.Schema({
    cnpj: {
        type: Number,
        required: [true, "O campo é obrigatório"]
    },

    nome: {
        type: String,
        required: [true, "O campo é obrigatório"]
    },

    password: {
        type: String,
        required: [true, "O campo é obrigatório"]
    }
})

enterpriseSchema.pre("save", async function () {
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
})

enterpriseSchema.methods.comparePassword = async function (candidatePassword) {
  const isMatch = await bcrypt.compare(candidatePassword, this.password);
  return isMatch;
};

module.exports = mongoose.model("Enterprise", enterpriseSchema)