const express = require("express")
const clientController = require("../controllers/ClientController")

const Router = express.Router()

//Create
Router.post('/client/register', clientController.register)
//Read
Router.get('/client/:id', clientController.findById)
//Update
Router.patch('/client/:id', clientController.updateById)
//Delete
Router.delete('/client/:id', clientController.deleteById)

module.exports = Router