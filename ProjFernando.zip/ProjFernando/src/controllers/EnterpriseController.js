const Enterprise = require("../models/Enterprise");
const { StatusCodes } = require("http-status-codes");

const register = async (req, res) => {
  const enterprise = await Enterprise.create(req.body);

  res.status(StatusCodes.CREATED).json({
    enterprise: {
      _id: enterprise.id,
      name: enterprise.nome,
      role: "empresa",
    },
  });
};

const findById = async (req, res) => {
  const enterprise = await Enterprise.findById(req.params.id)

  return res.status(StatusCodes.OK).json({enterprise})
};

const updateById = async (req,res) => {
    const updateEnterprise = await Enterprise.findByIdAndUpdate(req.params.id , req.body, {
        new: true,
    })

    return res.status(StatusCodes.OK).json({updateEnterprise})
}

const deleteById = async (req,res) => {
    const admin = await Enterprise.findByIdAndDelete(req.params.id)

    return res.status(StatusCodes.OK).json({ msg: 'Adm da empresa deletado com sucesso'})

}

const enterpriseController = { register, findById, updateById, deleteById };

module.exports = enterpriseController